"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Smartphone, Home, Users, BookOpen, Menu, Wifi, WifiOff } from "lucide-react"
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar"
import HomePage from "./components/home-page"
import AttendancePage from "./components/attendance-page"
import AppSidebar from "./components/app-sidebar"
import SavingSessionsPage from "./components/saving-sessions-page"
import PWAInstaller from "./components/pwa-installer"

type Page = "home" | "attendance" | "sessions"

interface Student {
  id: string
  name: string
  avatar?: string
}

interface AttendanceRecord {
  studentId: string
  status: "attend" | "missed" | "delay"
  delayAmount?: string
  timestamp: string
}

interface Session {
  id: string
  date: string
  attendanceRecords: AttendanceRecord[]
  duration: string
}

interface Mistake {
  name: string
}

interface SavingSession {
  id: number
  student: Student
  from: number
  to: number
  duration: number
  mistakes: Mistake[]
  points: number
  result: string
}

const mockSavingSessions: SavingSession[] = [
  {
    id: 1,
    student: { id: "1", name: "Ahmed Mohamed" },
    from: 15,
    to: 25,
    duration: 12,
    mistakes: [{ name: "Mispronunciation" }, { name: "Skipped word" }],
    points: 85,
    result: "Good",
  },
  {
    id: 2,
    student: { id: "2", name: "Fatima Ali" },
    from: 10,
    to: 20,
    duration: 15,
    mistakes: [{ name: "Wrong pronunciation" }, { name: "Hesitation" }, { name: "Repeated word" }],
    points: 70,
    result: "Average",
  },
  {
    id: 3,
    student: { id: "3", name: "Omar Hassan" },
    from: 5,
    to: 15,
    duration: 8,
    mistakes: [],
    points: 95,
    result: "Excellent",
  },
  {
    id: 4,
    student: { id: "4", name: "Nour Ibrahim" },
    from: 20,
    to: 30,
    duration: 18,
    mistakes: [{ name: "Mispronunciation" }, { name: "Wrong word" }, { name: "Skipped line" }, { name: "Hesitation" }],
    points: 55,
    result: "Needs Improvement",
  },
  {
    id: 5,
    student: { id: "5", name: "Youssef Ahmed" },
    from: 1,
    to: 10,
    duration: 10,
    mistakes: [{ name: "Mispronunciation" }],
    points: 80,
    result: "Good",
  },
]

const mockStudents: Student[] = [
  { id: "1", name: "Ahmed Mohamed" },
  { id: "2", name: "Fatima Ali" },
  { id: "3", name: "Omar Hassan" },
  { id: "4", name: "Nour Ibrahim" },
  { id: "5", name: "Youssef Ahmed" },
  { id: "6", name: "Maryam Khaled" },
]

const groupInfo = {
  name: "Mathematics Grade 10",
  teacher: "Dr. Sarah Johnson",
}

export default function PWAApp() {
  const [isOnline, setIsOnline] = useState(true)
  const [currentPage, setCurrentPage] = useState<Page>("home")
  const [isDesktop, setIsDesktop] = useState(false)
  const [students] = useState<Student[]>(mockStudents)
  const [sessions, setSessions] = useState<Session[]>([])
  const [savingSessions, setSavingSessions] = useState<SavingSession[]>(mockSavingSessions)
  const [serviceWorkerRegistered, setServiceWorkerRegistered] = useState(false)

  useEffect(() => {
    // Register service worker
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker
        .register("/api/sw")
        .then((registration) => {
          console.log("Service Worker registered with scope:", registration.scope)
          setServiceWorkerRegistered(true)
        })
        .catch((error) => {
          console.error("Service Worker registration failed:", error)
        })
    }

    // Check if desktop
    const checkDevice = () => {
      setIsDesktop(window.innerWidth >= 768)
    }

    checkDevice()
    window.addEventListener("resize", checkDevice)

    // Load sessions and saving sessions from localStorage
    try {
      const savedSessions = localStorage.getItem("pwa-sessions")
      if (savedSessions) {
        setSessions(JSON.parse(savedSessions))
      }

      const savedSavingSessions = localStorage.getItem("pwa-saving-sessions")
      if (savedSavingSessions) {
        setSavingSessions(JSON.parse(savedSavingSessions))
      } else {
        // Save mock data to localStorage on first load
        localStorage.setItem("pwa-saving-sessions", JSON.stringify(mockSavingSessions))
      }
    } catch (error) {
      console.error("Error loading data from localStorage:", error)
    }

    // Online/offline detection
    const handleOnline = () => setIsOnline(true)
    const handleOffline = () => setIsOnline(false)

    window.addEventListener("online", handleOnline)
    window.addEventListener("offline", handleOffline)

    setIsOnline(navigator.onLine)

    return () => {
      window.removeEventListener("resize", checkDevice)
      window.removeEventListener("online", handleOnline)
      window.removeEventListener("offline", handleOffline)
    }
  }, [])

  const saveSessions = (newSessions: Session[]) => {
    setSessions(newSessions)
    try {
      localStorage.setItem("pwa-sessions", JSON.stringify(newSessions))
    } catch (error) {
      console.error("Error saving sessions to localStorage:", error)
    }
  }

  const handleAttendanceSubmit = (attendanceRecords: AttendanceRecord[]) => {
    const newSession: Session = {
      id: Date.now().toString(),
      date: new Date().toLocaleDateString(),
      attendanceRecords,
      duration: "45 min",
    }

    const updatedSessions = [newSession, ...sessions]
    saveSessions(updatedSessions)
    setCurrentPage("sessions")
  }

  const getPageTitle = () => {
    switch (currentPage) {
      case "home":
        return "Home"
      case "attendance":
        return "Take Attendance"
      case "sessions":
        return "Sessions"
      default:
        return "Attendance App"
    }
  }

  if (isDesktop) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
              <Smartphone className="w-8 h-8 text-blue-600" />
            </div>
            <CardTitle className="text-2xl">Mobile App Only</CardTitle>
            <CardDescription className="text-base">This PWA is designed for mobile devices only</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Please access this application from your mobile device or resize your browser window to mobile size to use
              the app.
            </p>
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="text-sm font-medium text-blue-800">
                📱 Scan QR code or visit this URL on your mobile device
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <SidebarProvider>
      <div className="min-h-screen bg-background">
        <AppSidebar />

        {/* Main Content */}
        <div className="flex flex-col min-h-screen">
          {/* Header */}
          <header className="bg-card border-b border-border p-4 flex items-center justify-between sticky top-0 z-40">
            <div className="flex items-center gap-3">
              <SidebarTrigger>
                <Menu className="w-5 h-5" />
              </SidebarTrigger>
              <h1 className="font-semibold text-lg text-foreground">{getPageTitle()}</h1>
            </div>
            <div className="flex items-center gap-2">
              {isOnline ? (
                <Badge variant="secondary" className="text-xs bg-primary text-primary-foreground">
                  <Wifi className="w-3 h-3 mr-1" />
                  Online
                </Badge>
              ) : (
                <Badge variant="destructive" className="text-xs">
                  <WifiOff className="w-3 h-3 mr-1" />
                  Offline
                </Badge>
              )}
              {serviceWorkerRegistered && (
                <Badge variant="outline" className="text-xs bg-green-50 text-green-700 border-green-200">
                  PWA Ready
                </Badge>
              )}
            </div>
          </header>

          {/* Page Content */}
          <main className="flex-1 p-4 pb-20">
            {currentPage === "home" && <HomePage groupInfo={groupInfo} students={students} />}
            {currentPage === "attendance" && <AttendancePage students={students} onSubmit={handleAttendanceSubmit} />}
            {currentPage === "sessions" && <SavingSessionsPage savingSessions={savingSessions} />}
          </main>

          {/* Bottom Navigation */}
          <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border p-2">
            <div className="flex justify-around">
              <Button
                variant={currentPage === "home" ? "default" : "ghost"}
                size="sm"
                onClick={() => setCurrentPage("home")}
                className="flex flex-col items-center gap-1 h-auto py-2 px-3"
              >
                <Home className="w-4 h-4" />
                <span className="text-xs">Home</span>
              </Button>
              <Button
                variant={currentPage === "attendance" ? "default" : "ghost"}
                size="sm"
                onClick={() => setCurrentPage("attendance")}
                className="flex flex-col items-center gap-1 h-auto py-2 px-3"
              >
                <Users className="w-4 h-4" />
                <span className="text-xs">Attendance</span>
              </Button>
              <Button
                variant={currentPage === "sessions" ? "default" : "ghost"}
                size="sm"
                onClick={() => setCurrentPage("sessions")}
                className="flex flex-col items-center gap-1 h-auto py-2 px-3"
              >
                <BookOpen className="w-4 h-4" />
                <span className="text-xs">Sessions</span>
              </Button>
            </div>
          </nav>

          {/* PWA Install Prompt */}
          <PWAInstaller />
        </div>
      </div>
    </SidebarProvider>
  )
}
