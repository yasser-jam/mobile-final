// Service Worker Version
const CACHE_VERSION = "v1"
const CACHE_NAME = `attendance-pwa-${CACHE_VERSION}`

// Assets to cache immediately on install
const PRECACHE_ASSETS = ["/", "/manifest.json", "/icon-192.png", "/icon-512.png", "/offline.html"]

// Install event - cache core assets
self.addEventListener("install", (event) => {
  console.log("[ServiceWorker] Install")

  // Force waiting service worker to become active
  self.skipWaiting()

  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) => {
        console.log("[ServiceWorker] Pre-caching assets")
        return cache.addAll(PRECACHE_ASSETS)
      })
      .catch((err) => {
        console.error("[ServiceWorker] Pre-cache error:", err)
      }),
  )
})

// Activate event - clean up old caches
self.addEventListener("activate", (event) => {
  console.log("[ServiceWorker] Activate")

  // Take control of all clients immediately
  event.waitUntil(self.clients.claim())

  // Remove old caches
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log("[ServiceWorker] Removing old cache:", cacheName)
            return caches.delete(cacheName)
          }
        }),
      )
    }),
  )
})

// Fetch event - network first, falling back to cache
self.addEventListener("fetch", (event) => {
  // Skip cross-origin requests
  if (!event.request.url.startsWith(self.location.origin)) {
    return
  }

  // Skip non-GET requests
  if (event.request.method !== "GET") {
    return
  }

  // For HTML requests - network first, falling back to cache, then offline page
  if (event.request.headers.get("accept").includes("text/html")) {
    event.respondWith(
      fetch(event.request)
        .then((response) => {
          // Cache the latest version
          const responseClone = response.clone()
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseClone)
          })
          return response
        })
        .catch(() => {
          // If network fails, try cache
          return caches.match(event.request).then((cachedResponse) => {
            if (cachedResponse) {
              return cachedResponse
            }
            // If cache fails, show offline page
            return caches.match("/offline.html")
          })
        }),
    )
    return
  }

  // For other requests - stale-while-revalidate
  event.respondWith(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.match(event.request).then((cachedResponse) => {
        const fetchPromise = fetch(event.request)
          .then((networkResponse) => {
            // Update cache with fresh response
            cache.put(event.request, networkResponse.clone())
            return networkResponse
          })
          .catch((error) => {
            console.log("[ServiceWorker] Fetch error:", error)
          })

        // Return cached response immediately, or wait for network
        return cachedResponse || fetchPromise
      })
    }),
  )
})

// Handle messages from clients
self.addEventListener("message", (event) => {
  if (event.data && event.data.type === "SKIP_WAITING") {
    self.skipWaiting()
  }
})
